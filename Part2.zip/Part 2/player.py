from items import *
from map import rooms

inventory = [item_id, item_laptop]

# Start game at the reception
current_room = rooms["Reception"]
