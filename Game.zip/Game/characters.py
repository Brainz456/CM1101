#!/usr/bin/python3

# Jasmine
character_Jaz = {
    # The id that should be refer to this character in the code
    "id": "Jaz",
    
    # The items that this character is carrying
    "items": []
}

# Luke
character_Lulu = {
    "id": "Lulu",
    
    "items": []
}

# Jaymi
character_Jam = {
    "id": "Jam",
    
    "items": []
}

# Josh M
character_Joe = {
    "id": "Joe",
    
    "items": []
}

# Georgi
character_Gigi = {
    "id": "Gigi",
    
    "items": []
}

# Josh S
character_Josh = {
    "id": "Josh",
    
    "items": []
}

# The Other Random Person
character_Pete = {
    "id": "Pete",
    
    "items": []
}