from items import *
from map import rooms

inventory = []

# Start game at the reception
current_room = rooms["Home"]
